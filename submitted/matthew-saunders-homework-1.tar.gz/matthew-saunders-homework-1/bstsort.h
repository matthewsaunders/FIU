void strCompareUsage();
int compareWithCase(char*, char*);
int compareWithOutCase(char*, char*);
int strCompare(char*, char*, int);
