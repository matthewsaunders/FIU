/* COURSE      : COP 3530
 * Section     : U03
 * Semester    : Fall 2014
 * Instructor  : Alex Pelin
 * Author      : Matthew Saunders
 * Assignment #: 3
 * Due date    : October 21, 2014
 * Description : The Bn class is a binary node that holds the left node,
 *              right node, and the data of this node. This class also contains 
 *              methods #3, 5, 6, 8, 10 from  homework assignment 3.  
 *              These methods are:
 *              3 - levelsPlusIn
 *              5 - printByLevels
 *              6 - iterativeInOrder
 *              8 - equals
 *              10 - longestPath
 */
package assign3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Stack;

/**
 *
 * @author Matthew
 */
public class Bn<T> {

    //instance variables
    private T element;
    private Bn<T> left;
    private Bn<T> right;

    /**
     * Default constructor
     */
    public Bn() {
        this(null, null, null);
    }

    /**
     *
     * @param element
     * @param left
     * @param right
     */
    public Bn(T e, Bn<T> l, Bn<T> r) {
        this.element = e;
        this.left = l;
        this.right = r;
    }

    public void setLeft(Bn<T> e) {
        this.left = e;
    }

    public void setRight(Bn<T> e) {
        this.right = e;
    }

    public void setElement(T e) {
        this.element = e;
    }

    public Bn<T> getLeft() {
        return this.left;
    }

    public Bn<T> getRight() {
        return this.right;
    }

    public T getElement() {
        return this.element;
    }

    @Override
    public String toString() {
        return "" + this.element;
    }

    /**
     * METHOD 8 Check if a binary tree from node r is equivalent to this binary
     * tree.
     *
     * @param r Bn to check for equality with this Bn.
     * @return true iff the Bn tree from the root node r is identical to the
     * tree from this node, and the data values at each node are equal.
     */
    public boolean equals(Bn<T> r) {
        LinkedList<Bn<T>> q = new LinkedList();
        LinkedList<Bn<T>> qr = new LinkedList();
        q.add(this);
        qr.add(r);

        while (!q.isEmpty() && !qr.isEmpty()) {

            Bn<T> n = q.removeFirst();
            Bn<T> nr = qr.removeFirst();

            //check for equality of current node
            if (!n.getElement().equals(nr.getElement())) {
                return false;
            }

            if (n.getLeft() != null) {
                if (nr.getLeft() != null) {
                    q.addLast(n.getLeft());
                    qr.addLast(nr.getLeft());
                } else {
                    return false;
                }
            }
            if (n.getRight() != null) {
                if (nr.getRight() != null) {
                    q.addLast(n.getRight());
                    qr.addLast(nr.getRight());
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * METHOD 5 Print the subtree by node levels starting at this node. The
     * nodes on the same level are ordered from left to right.
     */
    public void printByLevels() {
        //create queue and add this element as root
        LinkedList<Bn<T>> q = new LinkedList();
        q.add(this);

        System.out.println("\nThe tree printed by levels:");

        //while there are items in the queue
        while (!q.isEmpty()) {
            Bn<T> n = q.removeFirst();

            //add left and right nodes to queue if they exist
            if (n.getLeft() != null) {
                q.addLast(n.getLeft());
            }
            if (n.getRight() != null) {
                q.addLast(n.getRight());
            }
            System.out.print(n.getElement() + " ");
        }
        System.out.print("\n");
    }

    /**
     * METHOD 6 Print tree in-order (left, root, right) from the current node.
     */
    public void iterativeInOrder() {
        Stack<Bn<T>> s = new Stack();
        Bn<T> current = this;

        while (current != null || !s.empty()) {
            if (current != null) {
                // process it, put it in the stack, and go left
                s.push(current);
                current = current.left;
            } else // pop the stack and go right
            {
                current = s.pop();
                System.out.print(current.element + " ");
                current = current.right;
            }
        }
    }

    /**
     * METHOD 3 Create a tree of Bn's from two arrays. The first array contains
     * the tree structure in-order and the second array contains the tree by
     * levels. Throws IllegalArgumentException if the arrays are not of equal
     * size, or if the next element in the array is not in the left or right
     * subtree.
     *
     * @param <T> data type of the elements in the arrays, Bn's
     * @param in array of element in-order (left, root, right)
     * @param levels array of elements by level
     * @return Bn root of the tree represented by the two arrays
     */
    public static <T> Bn<T> levelsPlusIn(T[] in, T[] levels) {
        Bn<T> node = null;
        T[] left;
        T[] right;
        int index;

        // if lengths are not equal, throw exception
        if (in.length != levels.length) {
            throw new IllegalArgumentException("Arrays don't have matching length");
        }

        // if array has any elements, make the first a Bn
        if (in.length > 0) {
            node = new Bn<>(levels[0], null, null);
        }

        // if there are more elements beyond the node made above
        if (in.length > 1) {
            //create the left and right subtrees of the current node
            for (index = 0; index < in.length && in[index] != levels[0]; index++);
            left = Arrays.copyOfRange(in, 0, index);
            right = Arrays.copyOfRange(in, index + 1, in.length);

            // if element is in left subtree, add the left subtree
            if (contains(levels[1], left)) {
                node.setLeft(levelsPlusIn(left, subArray(left, levels)));
                if (in.length > 2) {
                    if (contains(levels[2], right)) {
                        node.setRight(levelsPlusIn(right, subArray(right, levels)));
                    }
                }
                // if element is in right subtree, add the right subtree
            } else if (contains(levels[1], right)) {
                node.setRight(levelsPlusIn(right, subArray(right, levels)));
                // element is in neither subtree
            } else {
                throw new IllegalArgumentException("Node does not belong in subtree");
            }
        }
        return node;
    }

    /**
     * Test if an element exists in an array. Helper method used in
     * levelsPlusIn.
     *
     * @param <T> data type of the elements in the arrays, Bn's
     * @param e element to test for existence in array
     * @param list array to check for element
     * @return true iff element exists in the array.
     */
    public static <T> boolean contains(T e, T[] list) {
        for (T t : list) {
            if (t == e) {
                return true;
            }
        }
        return false;
    }

    /**
     * Create a subarray of array2 with only the elements contained in
     * array1. Mantains the ordering of elements from array2. Helper method used
     * in levelsPlusIn.
     *
     * @param <T> data type of the elements in the arrays, Bn's
     * @param a1 array with elements to keep
     * @param a2 array being parsed into subarray
     * @return subarray of elements from array1 in ordering of array2.
     */
    public static <T> T[] subArray(T[] a1, T[] a2) {
        T[] array = (T[]) new Object[a1.length];
        int[] index = new int[a1.length];
        int count = 0;

        for (int i = 0; i < a1.length; i++) {
            for (int j = 0; j < a2.length; j++) {
                if (a1[i] == a2[j]) {
                    index[count++] = j;
                }
            }
        }
        Arrays.sort(index);
        count = 0;

        for (int i = 0; i < array.length; i++) {
            array[i] = a2[index[i]];
        }

        return array;
    }

    /**
     * METHOD 10 Return an ArrayList of the Bns that represent the longest path
     * from the given root node. If multiple paths are the longest path, the
     * left most path is chosen.
     *
     * @param <T> data type of the Bn
     * @param root the root Bn of the tree/subtree
     * @return an ArrayList of Bn's that compose the longest path from the root
     * node.
     */
    public static <T> ArrayList<T> longestPath(Bn<T> root) {
        ArrayList<T> longest = new ArrayList();

        longest.add(root.getElement());

        // if root node has both left and right nodes
        if (root.left != null && root.right != null) {
            // Recursively add larger path from left or right node.  If both
            // paths are equal, add left.
            if (longestPath(root.getLeft()).size() >= longestPath(root.getRight()).size()) {
                longest.addAll(longestPath(root.getLeft()));
            } else {
                longest.addAll(longestPath(root.getRight()));
            }
            // At least one of the nodes is null.  Add path of other node.
        } else if (root.left != null) {
            longest.addAll(longestPath(root.getLeft()));
        } else if (root.right != null) {
            longest.addAll(longestPath(root.getRight()));
        }

        // Both left and right nodes are null, so return longest path
        return longest;
    }

}
