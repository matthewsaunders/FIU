/* COURSE      : COP 3530
 * Section     : U03
 * Semester    : Fall 2014
 * Instructor  : Alex Pelin
 * Author      : Matthew Saunders
 * Assignment #: 3
 * Due date    : October 21, 2014
 * Description : A test class for Bn.
 *
 */
package assign3;

import java.util.Arrays;

/**
 *
 * @author Matthew
 */
public class assign3_tester {

    public static void main(String[] args) {

        Bn z = new Bn("z", null, null);
        Bn a = new Bn("a", z, null);
        Bn b = new Bn("b", null, null);
        Bn c = new Bn("c", null, null);
        Bn d = new Bn("d", null, null);
        Bn e = new Bn("e", a, b);
        Bn f = new Bn("f", null, null);
        Bn g = new Bn("g", null, c);
        Bn h = new Bn("h", d, e);
        Bn i = new Bn("i", f, g);
        Bn j = new Bn("j", h, i);

        Bn jCOPY = j;

        System.out.println("The tree: ");
        System.out.println("     j ");
        System.out.println("    / \\");
        System.out.println("  h     i");
        System.out.println(" / \\   / \\");
        System.out.println("d   e f   g");
        System.out.println("     \\   / \\");
        System.out.println("      a b   c");

        System.out.print("\nprintByLevels:");
        j.printByLevels();

        System.out.println("\nequals:");
        System.out.print("j and jCOPY are... ");
        if (j.equals(jCOPY)) {
            System.out.print("EQUAL\n");
        } else {
            System.out.print("NOT EQUAL\n");
        }

        System.out.print("j and f are... ");
        if (j.equals(f)) {
            System.out.print("EQUAL\n");
        } else {
            System.out.print("NOT EQUAL\n");
        }

        System.out.println("\niterativeInOrder:");
        System.out.println("Expected:\td h z a e b j f i g c");
        System.out.print("Actual:\t\t");
        j.iterativeInOrder();

        System.out.println("\nExpected:\tf");
        System.out.print("Actual:\t\t");
        f.iterativeInOrder();

        System.out.println("\nExpected:\tf i g c");
        System.out.print("Actual:\t\t");
        i.iterativeInOrder();

        System.out.println("\n\nlongestPath:");
        System.out.println("Expected:\th j e a z");
        System.out.print("Actual:\t\t" + Bn.longestPath(j));

        System.out.println("\n\nLevelsPlusIn:");
        String[] level = {"j", "h", "i", "d", "e", "f", "g", "a", "b", "c", "z"};
        String[] in = {"d", "h", "e", "z", "a", "j", "f", "i", "b", "g", "c"};
        System.out.println("levels:\t" + Arrays.toString(level));
        System.out.println("in:\t" + Arrays.toString(in));

        System.out.print("\nDoes level contain 'z'... ");
        if (Bn.contains("z", level)) {
            System.out.print("TRUE\n");
        } else {
            System.out.print("FALSE\n");
        }

        System.out.print("Does level contain 'y'... ");
        if (Bn.contains("y", level)) {
            System.out.print("TRUE\n");
        } else {
            System.out.print("FALSE\n");
        }

        String[] sub = {"d", "h", "e", "z", "a"};
        System.out.println("\nsub:\t" + Arrays.toString(sub));
        System.out.println("Expected:\th d e a z");
        System.out.println("Actual:\t\t" + Arrays.toString(Bn.subArray(sub, level)));

        System.out.print("\nExpected:\t");
        j.printByLevels();
        System.out.print("Actual:\t\t");
        Bn.levelsPlusIn(in, level).printByLevels();

    }

}
